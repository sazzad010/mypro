<div class="text-center danger">
	<h1>
	404 <br>
	Not Found!
	</h1>
</div>